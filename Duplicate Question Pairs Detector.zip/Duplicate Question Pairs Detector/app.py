import streamlit as st
import helper
import pickle
from streamlit_extras.colored_header import colored_header
from streamlit_extras.stylable_container import stylable_container

# Load model
model = pickle.load(open('model.pkl', 'rb'))

# Page configuration
st.set_page_config(
    page_title="Duplicate Question Detector",
    page_icon="🔍",
    layout="centered"
)

# Custom CSS
st.markdown("""
<style>
    .stTextInput input {
        border-radius: 10px;
        padding: 12px;
    }
    
    .stButton>button {
        border-radius: 10px;
        padding: 12px 24px;
        background-color: #4F46E5;
        color: white;
        font-weight: bold;
        border: none;
        width: 100%;
        transition: all 0.3s;
    }
    
    .stButton>button:hover {
        background-color: #4338CA;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    
    .result-box {
        border-radius: 10px;
        padding: 20px;
        margin-top: 20px;
        text-align: center;
        font-size: 1.2rem;
        font-weight: bold;
    }
    
    .duplicate {
        background-color: #D1FAE5;
        color: #065F46;
    }
    
    .not-duplicate {
        background-color: #FEE2E2;
        color: #991B1B;
    }
</style>
""", unsafe_allow_html=True)

# Header
colored_header(
    label="🔍 Duplicate Question Pairs Detector",
    description="Check if two questions are duplicates",
    color_name="violet-70",
)

# Description
st.markdown("""
Enter two questions below to check if they are duplicates. 
This tool uses machine learning and Nlp to analyze semantic similarity.
""")

# Input fields
col1, col2 = st.columns(2)

with col1:
    q1 = st.text_input(
        "First Question",
        placeholder="Enter your first question here...",
        key="q1"
    )

with col2:
    q2 = st.text_input(
        "Second Question", 
        placeholder="Enter your second question here...",
        key="q2"
    )

# Find button
if st.button("Check for Duplicates", type="primary"):
    if q1 and q2:  # Only proceed if both fields have input
        with st.spinner("Analyzing questions..."):
            query = helper.query_point_creator(q1, q2)
            result = model.predict(query)[0]
            
            # Display result with animation
            if result:
                with stylable_container(
                    key="duplicate",
                    css_styles="""
                        {
                            background-color: #D1FAE5;
                            color: #065F46;
                            border-radius: 10px;
                            padding: 20px;
                        }
                    """
                ):
                    st.success("✅ These questions are duplicates!")
            else:
                with stylable_container(
                    key="not-duplicate",
                    css_styles="""
                        {
                            background-color: #FEE2E2;
                            color: #991B1B;
                            border-radius: 10px;
                            padding: 20px;
                        }
                    """
                ):
                    st.error("❌ These questions are not duplicates")
    else:
        st.warning("Please enter both questions to check")

# Footer
st.markdown("---")
st.caption("Built with ❤️ using Streamlit | with Good Accuracy | MNaveed122")